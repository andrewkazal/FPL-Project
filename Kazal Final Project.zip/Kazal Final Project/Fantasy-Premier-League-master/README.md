Fantasy-Premier-League
======================

A FPL library that gets all the basic stats for each player, gw-specific data for each player and season history of each player

## Notable Usages of this Repository

+ [Visualization by u/Dray11](https://www.reddit.com/r/FantasyPL/comments/9bjwra/created_a_very_crude_and_basic_comparison_chart/)

+ [Visualization website by @antoniaelek](http://fantasy.elek.hr/)

+ [FPL Captain Classifier by Raghunandh GS](https://medium.com/datacomics/building-an-fpl-captain-classifier-cf4ee343ebcc)

+ [My Personal Blog](http://vaastavanand.com/blog/)
