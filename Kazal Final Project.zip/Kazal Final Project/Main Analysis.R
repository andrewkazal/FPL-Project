# Starting analysis
library(data.table)
library(caret)
library(fmsb)
library(randomForest)
library(openintro)
library(tidyverse)
library(cluster)
library(factoextra)
library(dbscan)
library(dendextend)

setwd("/Users/andrewkazal/Desktop/School/MIDD/OneDrive\ -\ Middlebury\ College/Fall\ 18/Intro\ Data\ Science/Final\ Project/Fantasy-Premier-League-master/data")
all.gws <- fread("all.gws.csv")


# Questions to ask Alex:
# 1) Hiererarchical clustering vs k means clustering vs some other clustering?
# 2) Should I standardize my outcome so that I can compare results between different # of clusters and different algos (lm, RF)? 
# RMSE

  # - Compare: 7 clusters LM HC, 7 clusters RF HC, 12 clusters LM, 12 clusters RF HC,
  #            7 clusters LM Kmean, 7 clusters RF Kmean, 12 clusters Kmean, 12 clusters RF Kmean?
# 3) If yes, what metric should I use to evaluate each? Does this determine whether I make my outcome continuous vs. categorical?





# initial stuff
{
# Initial attempts
{# Get an idea for how many points players are earning
all.gws.sub <- all.gws %>%
  filter(minutes > 0) %>% 
  filter(selected > 100000)
mean(all.gws.sub$total_points)
sd(all.gws.sub$total_points)

gw.2016 <- all.gws %>% 
  filter(year == 2016)
anyDuplicated(gw.2016$id)


all.gws <- all.gws %>% 
  mutate(should.captain = ifelse(total_points >= 6, 1, 0))

all.gws %>% 
  group_by(id)


all.player.played <- all.gws %>%
  filter(minutes > 0)


mo.data <- all.gws %>%
  filter(name == "Mohamed_Salah") %>%
  filter(year == 2017)



salah <- lm(total_points ~ lag(assists) + lag(attempted_passes) + lag(big_chances_created) + lag(big_chances_missed)+
          lag(clean_sheets) + lag(clearances_blocks_interceptions) + lag(completed_passes) + lag(dribbles) +
          lag(errors_leading_to_goal) + lag(goals_conceded) + lag(goals_scored) +lag(tackled) + lag(winning_goals) +
          lag(tackles) + lag(was_home) + lag(yellow_cards),
          data = mo.data)

lm1.bw.salah <- step(salah, direction = "backward")
lm1.both.salah <- step(salah, direction = "both")


summary(lm1.bw.salah)
summary(lm1.both.salah)






aguero.data <- all.gws %>%
  filter(name == "Sergio_Ag�ero") %>%
  filter(year == 2017)



aguero <- lm(total_points ~ lag(assists) + lag(attempted_passes) + lag(big_chances_created) + lag(big_chances_missed)+
              lag(clean_sheets) + lag(clearances_blocks_interceptions) + lag(completed_passes) + lag(dribbles) +
              lag(errors_leading_to_goal) + lag(goals_conceded) + lag(goals_scored) +lag(tackled) + lag(winning_goals) +
              lag(tackles) + lag(was_home) + lag(yellow_cards),
            data = aguero.data)

lm1.bw.aguero <- step(aguero, direction = "backward")
lm1.both.aguero <- step(aguero, direction = "both")


summary(lm1.bw.aguero)
summary(lm1.both.aguero)





kante.data <- all.gws %>%
  filter(name == "N'Golo_Kant�") %>%
  filter(year == 2017)

test.points <- kante.data
test.predictions <- predict.lm(lm1.both.aguero, kante.data)
test.combined <- data.frame(Lag_CBI = lag(test.points$clearances_blocks_interceptions),
                            Predictions = test.predictions)

kante.data %>%
  ggplot(aes(x = lag(kante.data$clearances_blocks_interceptions), y = total_points)) +
  geom_point(aes(color = lag(kante.data$tackles))) +
  geom_line(data = test.combined,
            mapping = aes(x = Lag_CBI, y = Predictions),
            color = "red")





mane.data <- all.gws %>%
  filter(name == "Sadio_Man�") %>%
  filter(year == 2017 | year == 2016)

test.points <- mane.data
test.predictions <- predict.lm(lm1.both.aguero, mane.data)
test.combined <- data.frame(Lag_CBI = lag(test.points$clearances_blocks_interceptions),
                            Predictions = test.predictions)

mane.data %>%
  ggplot(aes(x = lag(mane.data$clearances_blocks_interceptions), y = total_points)) +
  geom_point(aes(color = lag(mane.data$tackles))) +
  geom_line(data = test.combined,
            mapping = aes(x = Lag_CBI, y = Predictions),
            color = "red")





all.player.played <- all.gws %>%
  filter(minutes > 0) %>% 
  mutate(should.captain = ifelse(total_points >= 6, 1, 0)) %>% 
  select()}






# First clustering attempt (with Joshua Harrop)
# first tried a selection of players
# then tried with joshua
{# Hiererarchical clustering


# Normalize our variables (z-scores)
scaled.us <- scale(all.gws[, -1])

# Calculate distance between states
distance.matrix <- dist(scaled.us) # Default is euclidean distance

# Do HC clustering
hc1 <- hclust(distance.matrix)

# Make a plot of the clustering
plot(hc1,
     cex = 0.6,
     hang = -1)




sample.positions <- all.gws %>% 
  filter(name == "Sergio_Ag�ero" | name == "Eden_Hazard" | name == "N'Golo_Kant�" | name == "Vincent_Kompany" |
         name == "Romelu_Lukaku" | name == "Joe_Hart" | name == "Lukasz_Fabianski" | name == "Petr_Cech") %>% 
  select(name, attempted_passes, goals_conceded, assists, completed_passes, dribbles, fouls) %>% 
  group_by(name) %>% 
  summarize(mean.attempt.pass = mean(attempted_passes),
            mean.goals = mean(goals_conceded),
            mean.assists = mean(assists),
            mean.comp.pass = mean(completed_passes),
            mean.dribbles = mean(dribbles),
            mean.fouls = mean(fouls))




# Normalize our variables (z-scores)
scaled.us <- scale(sample.positions[, -1])

# Calculate distance between states
distance.matrix <- dist(scaled.us) # Default is euclidean distance

# Do HC clustering
hc1 <- hclust(distance.matrix)

# Make a plot of the clustering
plot(hc1,
     cex = 0.6,
     hang = -1)

# cutree(hc1, k = TRY DIFFERENT NUMBERS )


x <- sample.positions[,-1]
d4 <- as.dendrogram(hclust(dist(scale(x))))
labels(d4) <- apply(sample.positions[,1], 1, paste, collapse = "_")[order.dendrogram(d4)]

d4 <- set(d4, "labels_cex", 0.6)
d4 <- color_branches(d4, k = 7)


labels_colors(d4) <- 1:8
colors = c("#ff0000","#0aa000","#016d68","#0066c6","#013566","#44005b",
           "#000000","#848ce8")
clus7 = cutree(d4, k = 8)
plot(as.phylo.dendrogram(d4), tip.color = colors[clus7],
     label.offset = 0.25, cex = 0.7)




# Steps for further analysis:
# Do this clustering for more variables and for all players
  #Cut at a height that makes 10 groups
  #Filter by those groups and make sure that those people make sense to be in those groups
# Decide where to cut on my "cluster dendogram"
# Using this height, I will get an output assigning each player to a cluster
# Group by this cluster value, group by game week (round) and year (to get unique matches) 
# Now use lagged variables to predict game week point for each of these groups









# Clustering round 2



summarizled.vars <- all.gws %>% 
  group_by(name) %>% 
  summarize(mean.assists = mean(assists),
            mean.attempt.pass = mean(attempted_passes),
            mean.big.create = mean(big_chances_created),
            mean.big.miss = mean(big_chances_missed),
            mean.cs = mean(clean_sheets),
            mean.cbs = mean(clearances_blocks_interceptions),
            mean.comp.pass = mean(completed_passes),
            mean.creativity = mean(creativity),
            mean.dribbles = mean(dribbles),
            mean.err = mean(errors_leading_to_goal),
            mean.fouls = mean(fouls),
            mean.goals.c = mean(goals_conceded),
            mean.goals.s = mean(goals_scored),
            mean.offs = mean(offside),
            mean.cross = mean(open_play_crosses),
            mean.owng = mean(own_goals),
            mean.pen.save = mean(penalties_saved),
            mean.red = mean(red_cards),
            mean.saves = mean(saves),
            mean.tackled = mean(tackled),
            mean.tackles = mean(tackles),
            mean.win.goal = mean(winning_goals))



# Normalize our variables (z-scores)
scaled.us <- scale(summarized.vars[, -1])

# Calculate distance between states
distance.matrix <- dist(scaled.us) # Default is euclidean distance

# Do HC clustering
hc1 <- hclust(distance.matrix)

# Make a plot of the clustering
plot(hc1,
     cex = 0.6,
     hang = -1)


summarized.vars <- summarized.vars %>% 
  mutate(tree = cutree(hc1, k = 2))

x <- summarized.vars[,-1]
d4 <- as.dendrogram(hclust(dist(scale(x))))


plot(as.phylo.dendrogram(d4),
     label.offset = 0.25, cex = 0.7)



}




# now attempting clustering without joshua
{
summarized.vars.no.josh <- all.gws %>% 
  group_by(name) %>% 
  summarize(mean.assists = mean(assists),
            mean.attempt.pass = mean(attempted_passes),
            mean.big.create = mean(big_chances_created),
            mean.big.miss = mean(big_chances_missed),
            mean.cs = mean(clean_sheets),
            mean.cbs = mean(clearances_blocks_interceptions),
            mean.comp.pass = mean(completed_passes),
            mean.creativity = mean(creativity),
            mean.dribbles = mean(dribbles),
            mean.err = mean(errors_leading_to_goal),
            mean.fouls = mean(fouls),
            mean.goals.c = mean(goals_conceded),
            mean.goals.s = mean(goals_scored),
            mean.offs = mean(offside),
            mean.cross = mean(open_play_crosses),
            mean.owng = mean(own_goals),
            mean.pen.save = mean(penalties_saved),
            mean.red = mean(red_cards),
            mean.saves = mean(saves),
            mean.tackled = mean(tackled),
            mean.tackles = mean(tackles),
            mean.win.goal = mean(winning_goals),
            mean.mins = mean(minutes)) %>% 
  filter(mean.mins != 0) %>% 
  filter(name != "Joshua_Harrop")


# Joshua played 1 game, scored a goal, never came back




# Normalize our variables (z-scores)
scaled.us <- scale(summarized.vars.no.josh[, -1])

# Calculate distance between states
distance.matrix <- dist(scaled.us) # Default is euclidean distance

# Do HC clustering
hc.no.josh <- hclust(distance.matrix)

# Make a plot of the clustering
plot(hc.no.josh,
     cex = 0.6,
     hang = -1)

rect.hclust(hc.josh, k = 2, border = 1:11)


summarized.vars.no.josh <- summarized.vars.no.josh %>% 
  mutate(tree = cutree(hc.josh, k = 2))


x <- summarized.vars.no.josh[,-1]
d4 <- as.dendrogram(hclust(dist(scale(x))))


plot(as.phylo.dendrogram(d4),
     label.offset = 0.25, cex = 0.7)


}
}



# Hierachical clustering
{
# Now attempting with only players that played in a gameweek and players that played at least 20 weeks
# Hiererachical clustering for 7 clusters
{
games.played <- all.gws %>% 
  group_by(name) %>% 
  mutate(played = ifelse(minutes != 0, 1, 0)) %>% 
  filter(minutes != 0) %>% 
  summarize(num.games = sum(played)) 

all.vars.games.played <- left_join(all.gws, games.played)
  
  
summarized.vars.at.least.20 <- all.vars.games.played %>% 
  filter(num.games >= 20) %>% 
  group_by(name) %>% 
  summarize(mean.assists = mean(assists),
            mean.attempt.pass = mean(attempted_passes),
            mean.big.create = mean(big_chances_created),
            mean.big.miss = mean(big_chances_missed),
            mean.cs = mean(clean_sheets),
            mean.cbs = mean(clearances_blocks_interceptions),
            mean.comp.pass = mean(completed_passes),
            mean.creativity = mean(creativity),
            mean.dribbles = mean(dribbles),
            mean.err = mean(errors_leading_to_goal),
            mean.fouls = mean(fouls),
            mean.goals.c = mean(goals_conceded),
            mean.goals.s = mean(goals_scored),
            mean.offs = mean(offside),
            mean.cross = mean(open_play_crosses),
            mean.owng = mean(own_goals),
            mean.pen.save = mean(penalties_saved),
            mean.red = mean(red_cards),
            mean.saves = mean(saves),
            mean.tackled = mean(tackled),
            mean.tackles = mean(tackles),
            mean.win.goal = mean(winning_goals))
  







# Normalize our variables (z-scores)
scaled.us <- scale(summarized.vars.at.least.20[, -1])

# Calculate distance between states
distance.matrix <- dist(scaled.us) # Default is euclidean distance

# Do HC clustering
hc.20 <- hclust(distance.matrix)

# Make a plot of the clustering
plot(hc.20,
     cex = 0.6,
     hang = -1)

rect.hclust(hc.20, k = 7, border = 1:7)


summarized.vars.at.least.20 <- summarized.vars.at.least.20 %>% 
  mutate(tree = cutree(hc.20, k = 7))

# MY REASON FOR DOING K = 7 IS BECAUSE THERE ARE: 1)GOALIES 2)CB 3)WB 4)CM 5)WM 6)STRIKERS 7)WINGERS

# Get a sense for who is in each cluster


summarized.vars.at.least.20 %>% 
  filter(tree == 1) %>% 
  select(name) %>% 
  sample_n(5)

summarized.vars.at.least.20 %>% 
  filter(tree == 2) %>% 
  select(name) %>% 
  sample_n(5)

summarized.vars.at.least.20 %>% 
  filter(tree == 3) %>% 
  select(name) %>% 
  sample_n(5)

summarized.vars.at.least.20 %>% 
  filter(tree == 4) %>% 
  select(name) %>% 
  sample_n(5)

summarized.vars.at.least.20 %>% 
  filter(tree == 5) %>% 
  select(name) %>% 
  sample_n(5)

summarized.vars.at.least.20 %>% 
  filter(tree == 6) %>% 
  select(name) %>% 
  sample_n(4)

summarized.vars.at.least.20 %>% 
  filter(tree == 7) %>% 
  select(name) %>% 
  sample_n(1)





to.join <- summarized.vars.at.least.20 %>% 
  select(name, tree)

gws.tree.7.hc <- left_join(all.gws, to.join)

}

  # plot
  {
  indexes <- sample(1:nrow(summarized.vars.at.least.20), .5*nrow(summarized.vars.at.least.20)) 
  rand.sampled <- summarized.vars.at.least.20[indexes, ]
  
  x <- rand.sampled[,-1]
  d4 <- as.dendrogram(hclust(dist(scale(x))))
  labels(d4) <- apply(rand.sampled[,1], 1, paste, collapse = "_")[order.dendrogram(d4)]
  
  d4 <- set(d4, "labels_cex", 0.6)
  d4 <- color_branches(d4, k = 7)

  
  labels_colors(dend) <- 1:7
  colors = c("#ff0000","#0aa000","#016d68","#013566","#44005b",
             "#000000","#848ce8")
  clus7 = cutree(d4, k = 7)
  plot(as.phylo.dendrogram(d4), type = "fan", tip.color = colors[clus7],
       label.offset = 0.25, cex = 0.7)

  }
  
  
# Hierachical clustering for 12 clusters
{
  games.played <- all.gws %>% 
    group_by(name) %>% 
    mutate(played = ifelse(minutes != 0, 1, 0)) %>% 
    filter(minutes != 0) %>% 
    summarize(num.games = sum(played)) 
  
  all.vars.games.played <- left_join(all.gws, games.played)
  
  
  summarized.vars.at.least.20 <- all.vars.games.played %>% 
    filter(num.games >= 20) %>% 
    group_by(name) %>% 
    summarize(mean.assists = mean(assists),
              mean.attempt.pass = mean(attempted_passes),
              mean.big.create = mean(big_chances_created),
              mean.big.miss = mean(big_chances_missed),
              mean.cs = mean(clean_sheets),
              mean.cbs = mean(clearances_blocks_interceptions),
              mean.comp.pass = mean(completed_passes),
              mean.creativity = mean(creativity),
              mean.dribbles = mean(dribbles),
              mean.err = mean(errors_leading_to_goal),
              mean.fouls = mean(fouls),
              mean.goals.c = mean(goals_conceded),
              mean.goals.s = mean(goals_scored),
              mean.offs = mean(offside),
              mean.cross = mean(open_play_crosses),
              mean.owng = mean(own_goals),
              mean.pen.save = mean(penalties_saved),
              mean.red = mean(red_cards),
              mean.saves = mean(saves),
              mean.tackled = mean(tackled),
              mean.tackles = mean(tackles),
              mean.win.goal = mean(winning_goals))
  
  # Normalize our variables (z-scores)
  scaled.us <- scale(summarized.vars.at.least.20[, -1])
  
  # Calculate distance between states
  distance.matrix <- dist(scaled.us) # Default is euclidean distance
  
  # Do HC clustering
  hc.20 <- hclust(distance.matrix)
  
  # Make a plot of the clustering
  plot(hc.20,
       cex = 0.6,
       hang = -1)
  
  rect.hclust(hc.20, k = 12, border = 1:12)
  
  
  summarized.vars.at.least.20.12 <- summarized.vars.at.least.20 %>% 
    mutate(tree = cutree(hc.20, k = 12))
  
  
  # Get a sense for who is in each cluster
  
  
  summarized.vars.at.least.20.12 %>% 
    filter(tree == 1) %>% 
    select(name) %>% 
    sample_n(5)
  
  summarized.vars.at.least.20.12 %>% 
    filter(tree == 2) %>% 
    select(name) %>% 
    sample_n(5)
  
  summarized.vars.at.least.20.12 %>% 
    filter(tree == 3) %>% 
    select(name) %>% 
    sample_n(5)
  
  summarized.vars.at.least.20.12 %>% 
    filter(tree == 4) %>% 
    select(name) %>% 
    sample_n(5)
  
  summarized.vars.at.least.20.12 %>% 
    filter(tree == 5) %>% 
    select(name) %>% 
    sample_n(5)
  
  summarized.vars.at.least.20.12 %>% 
    filter(tree == 6) %>% 
    select(name) %>% 
    sample_n(5)
  
  summarized.vars.at.least.20.12 %>% 
    filter(tree == 7) %>% 
    select(name) %>% 
    sample_n(5)
  
  summarized.vars.at.least.20.12 %>% 
    filter(tree == 8) %>% 
    select(name) %>% 
    sample_n(5)
  
  summarized.vars.at.least.20.12 %>% 
    filter(tree == 9) %>% 
    select(name) %>% 
    sample_n(4)
  
  summarized.vars.at.least.20.12 %>% 
    filter(tree == 10) %>% 
    select(name) %>% 
    sample_n(5)
  
  summarized.vars.at.least.20.12 %>% 
    filter(tree == 11) %>% 
    select(name) %>% 
    sample_n(4)
  
  summarized.vars.at.least.20.12 %>% 
    filter(tree == 12) %>% 
    select(name) %>% 
    sample_n(1)
  
  
  
  
  
  to.join.12 <- summarized.vars.at.least.20.12 %>% 
    select(name, tree)
  
  gws.tree.12.hc <- left_join(all.gws, to.join.12)

}
  
  # plot
  {
    indexes <- sample(1:nrow(summarized.vars.at.least.20), .5*nrow(summarized.vars.at.least.20)) 
    rand.sampled <- summarized.vars.at.least.20[indexes, ]
    
    x <- rand.sampled[,-1]
    d4 <- as.dendrogram(hclust(dist(scale(x))))
    labels(d4) <- apply(rand.sampled[,1], 1, paste, collapse = "_")[order.dendrogram(d4)]
    
    d4 <- set(d4, "labels_cex", 0.6)
    d4 <- color_branches(d4, k = 12)
    
    
    labels_colors(dend) <- 1:12
    colors = c("#ff0000","#960000","#0aa000","#066300","#016d68","#0066c6","#013566","#8c01ba","#44005b",
               "#a00371","#000000","#848ce8")
    clus7 = cutree(d4, k = 12)
    plot(as.phylo.dendrogram(d4), type = "fan", tip.color = colors[clus7],
         label.offset = 0.25, cex = 0.7)
    
  }
  
}



# k means clustering
{
  
# kmeans for 7 clusters
{
  games.played <- all.gws %>% 
    group_by(name) %>% 
    mutate(played = ifelse(minutes != 0, 1, 0)) %>% 
    filter(minutes != 0) %>% 
    summarize(num.games = sum(played)) 
  
  all.vars.games.played <- left_join(all.gws, games.played)
  
  
  summarized.vars.at.least.20 <- all.vars.games.played %>% 
    filter(num.games >= 20) %>% 
    group_by(name) %>% 
    summarize(mean.assists = mean(assists),
              mean.attempt.pass = mean(attempted_passes),
              mean.big.create = mean(big_chances_created),
              mean.big.miss = mean(big_chances_missed),
              mean.cs = mean(clean_sheets),
              mean.cbs = mean(clearances_blocks_interceptions),
              mean.comp.pass = mean(completed_passes),
              mean.creativity = mean(creativity),
              mean.dribbles = mean(dribbles),
              mean.err = mean(errors_leading_to_goal),
              mean.fouls = mean(fouls),
              mean.goals.c = mean(goals_conceded),
              mean.goals.s = mean(goals_scored),
              mean.offs = mean(offside),
              mean.cross = mean(open_play_crosses),
              mean.owng = mean(own_goals),
              mean.pen.save = mean(penalties_saved),
              mean.red = mean(red_cards),
              mean.saves = mean(saves),
              mean.tackled = mean(tackled),
              mean.tackles = mean(tackles),
              mean.win.goal = mean(winning_goals))
  
  
  
  clusters.7.k <- kmeans(x = summarized.vars.at.least.20[,-1],
                         centers = 7)
  
  tree <- as.vector(clusters.7.k$cluster)
  
  summarized.vars.at.least.20 <- cbind(summarized.vars.at.least.20, tree)
    
  
  # Get a sense for who is in each cluster
  
  
  summarized.vars.at.least.20 %>% 
    filter(tree == 1) %>% 
    select(name) %>% 
    sample_n(5)
  
  summarized.vars.at.least.20 %>% 
    filter(tree == 2) %>% 
    select(name) %>% 
    sample_n(5)
  
  summarized.vars.at.least.20 %>% 
    filter(tree == 3) %>% 
    select(name) %>% 
    sample_n(5)
  
  summarized.vars.at.least.20 %>% 
    filter(tree == 4) %>% 
    select(name) %>% 
    sample_n(5)
  
  summarized.vars.at.least.20 %>% 
    filter(tree == 5) %>% 
    select(name) %>% 
    sample_n(5)
  
  summarized.vars.at.least.20 %>% 
    filter(tree == 6) %>% 
    select(name) %>% 
    sample_n(4)
  
  summarized.vars.at.least.20 %>% 
    filter(tree == 7) %>% 
    select(name) %>% 
    sample_n(1)
  
  
  
  
  
  to.join <- summarized.vars.at.least.20 %>% 
    select(name, tree)
  
  gws.tree.7.k <- left_join(all.gws, to.join)
  
}


# kmeans for 12 clusters
{
    games.played <- all.gws %>% 
      group_by(name) %>% 
      mutate(played = ifelse(minutes != 0, 1, 0)) %>% 
      filter(minutes != 0) %>% 
      summarize(num.games = sum(played)) 
    
    all.vars.games.played <- left_join(all.gws, games.played)
    
    
    summarized.vars.at.least.20 <- all.vars.games.played %>% 
      filter(num.games >= 20) %>% 
      group_by(name) %>% 
      summarize(mean.assists = mean(assists),
                mean.attempt.pass = mean(attempted_passes),
                mean.big.create = mean(big_chances_created),
                mean.big.miss = mean(big_chances_missed),
                mean.cs = mean(clean_sheets),
                mean.cbs = mean(clearances_blocks_interceptions),
                mean.comp.pass = mean(completed_passes),
                mean.creativity = mean(creativity),
                mean.dribbles = mean(dribbles),
                mean.err = mean(errors_leading_to_goal),
                mean.fouls = mean(fouls),
                mean.goals.c = mean(goals_conceded),
                mean.goals.s = mean(goals_scored),
                mean.offs = mean(offside),
                mean.cross = mean(open_play_crosses),
                mean.owng = mean(own_goals),
                mean.pen.save = mean(penalties_saved),
                mean.red = mean(red_cards),
                mean.saves = mean(saves),
                mean.tackled = mean(tackled),
                mean.tackles = mean(tackles),
                mean.win.goal = mean(winning_goals))
    
    
    
    clusters.12.k <- kmeans(x = summarized.vars.at.least.20[,-1],
                           centers = 12)
    
    tree <- as.vector(clusters.12.k$cluster)
    
    summarized.vars.at.least.20 <- cbind(summarized.vars.at.least.20, tree)
    
    
    # Get a sense for who is in each cluster
    
    
    summarized.vars.at.least.20 %>% 
      filter(tree == 1) %>% 
      select(name) %>% 
      sample_n(5)
    
    summarized.vars.at.least.20 %>% 
      filter(tree == 2) %>% 
      select(name) %>% 
      sample_n(5)
    
    summarized.vars.at.least.20 %>% 
      filter(tree == 3) %>% 
      select(name) %>% 
      sample_n(5)
    
    summarized.vars.at.least.20 %>% 
      filter(tree == 4) %>% 
      select(name) %>% 
      sample_n(5)
    
    summarized.vars.at.least.20 %>% 
      filter(tree == 5) %>% 
      select(name) %>% 
      sample_n(5)
    
    summarized.vars.at.least.20 %>% 
      filter(tree == 6) %>% 
      select(name) %>% 
      sample_n(5)
    
    summarized.vars.at.least.20 %>% 
      filter(tree == 7) %>% 
      select(name) %>% 
      sample_n(5)
    
    summarized.vars.at.least.20 %>% 
      filter(tree == 8) %>% 
      select(name) %>% 
      sample_n(5)
    
    summarized.vars.at.least.20 %>% 
      filter(tree == 9) %>% 
      select(name) %>% 
      sample_n(5)
    
    summarized.vars.at.least.20 %>% 
      filter(tree == 10) %>% 
      select(name) %>% 
      sample_n(5)
    
    summarized.vars.at.least.20 %>% 
      filter(tree == 11) %>% 
      select(name) %>% 
      sample_n(5)
    
    summarized.vars.at.least.20 %>% 
      filter(tree == 12) %>% 
      select(name) %>% 
      sample_n(5)
    
    
    to.join <- summarized.vars.at.least.20 %>% 
      select(name, tree)
    
    gws.tree.12.k <- left_join(all.gws, to.join)
    
  }
  
  
}



# linear models
{
# Now it's time to make linear models within each cluster
# RMSE value for linear model for 7 clusters made from hierachical
{
gws.tree.avs.7.hc <- gws.tree.7.hc %>% 
  group_by(year, round, tree) %>% 
  summarize(mean.assists = mean(assists),
            mean.attempt.pass = mean(attempted_passes),
            mean.big.create = mean(big_chances_created),
            mean.big.miss = mean(big_chances_missed),
            mean.cs = mean(clean_sheets),
            mean.cbs = mean(clearances_blocks_interceptions),
            mean.comp.pass = mean(completed_passes),
            mean.creativity = mean(creativity),
            mean.dribbles = mean(dribbles),
            mean.err = mean(errors_leading_to_goal),
            mean.fouls = mean(fouls),
            mean.goals.c = mean(goals_conceded),
            mean.goals.s = mean(goals_scored),
            mean.offs = mean(offside),
            mean.cross = mean(open_play_crosses),
            mean.owng = mean(own_goals),
            mean.pen.save = mean(penalties_saved),
            mean.red = mean(red_cards),
            mean.saves = mean(saves),
            mean.tackled = mean(tackled),
            mean.tackles = mean(tackles),
            mean.win.goal = mean(winning_goals),
            mean.points = mean(total_points)) %>% 
  filter(is.na(tree) != TRUE)



stepped.lm.tree.7 <- list()
rmse.values.hc.lm.7 <- NULL
for(i in 1:6){
gws.tree.avs.1 <- gws.tree.avs.7.hc %>% 
  filter(tree == i) %>% 
  arrange(-year, -round)

lagged.gws.tree.avs.1 <- as.data.frame(apply(gws.tree.avs.1, 2, lag))

fut.points <- gws.tree.avs.1$mean.points

lagged.gws.tree.avs.1.points <- cbind(lagged.gws.tree.avs.1, fut.points)


to.lm.train <- lagged.gws.tree.avs.1.points %>% 
  filter(year == 2016) 

to.lm.test <- lagged.gws.tree.avs.1.points %>% 
  filter(year != 2016)


lm.tree <- lm(fut.points ~ . -year -round -tree -mean.points,
                data = to.lm.train)

stepped.lm.tree.7[[i]] <- step(lm.tree, direction = "both")

predictions.lm.12 <- predict(stepped.lm.tree.7[[i]], to.lm.test[,-27])

true.values <- to.lm.test$fut.points

RMSE.data <- as.data.frame(cbind(true.values, predictions.lm.12))

rmse.values.hc.lm.7[i] <- RMSE.data %>% 
  summarize(rmse = RMSE(RMSE.data$predictions.lm.12, RMSE.data$true.values))


}


for(i in 7){
  gws.tree.avs.1.12 <- gws.tree.avs.7.hc %>% 
    filter(tree == i) %>% 
    arrange(-year, -round)
  
  lagged.gws.tree.avs.1.12 <- as.data.frame(apply(gws.tree.avs.1.12, 2, lag))
  
  fut.points.12 <- gws.tree.avs.1.12$mean.points
  
  lagged.gws.tree.avs.1.12.points <- cbind(lagged.gws.tree.avs.1.12, fut.points.12)
  
  
  to.lm.train <- lagged.gws.tree.avs.1.12.points %>% 
    filter(year == 2017 & round < 25 ) %>% 
    select(-year, -round, -tree, -mean.points)
  
  
  to.lm.test <- lagged.gws.tree.avs.1.12.points %>% 
    filter((year == 2017 & round >= 25)  |  (year==2018)) %>%
    select(-year, -round, -tree, -mean.points)
  
  
  lm.tree <- lm(fut.points.12 ~ .,
                data = to.lm.train)
  
  stepped.lm.tree.7[[i]] <- step(lm.tree, direction = "both")
  
  predictions.lm.12 <- predict(stepped.lm.tree.7[[i]], to.lm.test[,-27])
  
  true.values <- to.lm.test$fut.points.12
  
  RMSE.data <- as.data.frame(cbind(true.values, predictions.lm.12))
  
  rmse.values.hc.lm.7[i] <- RMSE.data %>% 
    summarize(rmse = RMSE(RMSE.data$predictions.lm.12, RMSE.data$true.values))
  
  
}


}


  # Now it's time to make linear models within each cluster
  # RMSE value for linear model for 7 clusters made from kmeans
  {
    gws.tree.avs.7.k <- gws.tree.7.k %>% 
      group_by(year, round, tree) %>% 
      summarize(mean.assists = mean(assists),
                mean.attempt.pass = mean(attempted_passes),
                mean.big.create = mean(big_chances_created),
                mean.big.miss = mean(big_chances_missed),
                mean.cs = mean(clean_sheets),
                mean.cbs = mean(clearances_blocks_interceptions),
                mean.comp.pass = mean(completed_passes),
                mean.creativity = mean(creativity),
                mean.dribbles = mean(dribbles),
                mean.err = mean(errors_leading_to_goal),
                mean.fouls = mean(fouls),
                mean.goals.c = mean(goals_conceded),
                mean.goals.s = mean(goals_scored),
                mean.offs = mean(offside),
                mean.cross = mean(open_play_crosses),
                mean.owng = mean(own_goals),
                mean.pen.save = mean(penalties_saved),
                mean.red = mean(red_cards),
                mean.saves = mean(saves),
                mean.tackled = mean(tackled),
                mean.tackles = mean(tackles),
                mean.win.goal = mean(winning_goals),
                mean.points = mean(total_points)) %>% 
      filter(is.na(tree) != TRUE)
    
    
    
    
      
      
      
      stepped.lm.tree.7 <- list()
      rmse.values.k.lm.7 <- NULL
      for(i in 1:7){
        gws.tree.avs.1 <- gws.tree.avs.7.k %>% 
          filter(tree == i) %>% 
          arrange(-year, -round)
        
        lagged.gws.tree.avs.1 <- as.data.frame(apply(gws.tree.avs.1, 2, lag))
        
        fut.points <- gws.tree.avs.1$mean.points
        
        lagged.gws.tree.avs.1.points <- cbind(lagged.gws.tree.avs.1, fut.points)
        
        
        to.lm.train <- lagged.gws.tree.avs.1.points %>% 
          filter(year == 2016) 
        
        to.lm.test <- lagged.gws.tree.avs.1.points %>% 
          filter(year != 2016)
        
        
        lm.tree <- lm(fut.points ~ . -year -round -tree -mean.points,
                      data = to.lm.train)
        
        stepped.lm.tree.7[[i]] <- step(lm.tree, direction = "both")
        
        predictions.lm.12 <- predict(stepped.lm.tree.7[[i]], to.lm.test[,-27])
        
        true.values <- to.lm.test$fut.points
        
        RMSE.data <- as.data.frame(cbind(true.values, predictions.lm.12))
        
        rmse.values.k.lm.7[i] <- RMSE.data %>% 
          summarize(rmse = RMSE(RMSE.data$predictions.lm.12, RMSE.data$true.values))
        
        
      }
    
      
      
    
  }


# Now try 12 clusters instead of 7
# Reason being: 1 for each position and 2 for strikers (false 9) DO I NEED TO SUPPORT THIS WITH EVIDENCE AS TO FALSE 9 VS OTHER POSITION?
# RMSE value for linear model for 12 clusters made from hierachical
{
  gws.tree.avs.12.hc <- gws.tree.12.hc %>% 
    group_by(year, round, tree) %>% 
    summarize(mean.assists = mean(assists),
              mean.attempt.pass = mean(attempted_passes),
              mean.big.create = mean(big_chances_created),
              mean.big.miss = mean(big_chances_missed),
              mean.cs = mean(clean_sheets),
              mean.cbs = mean(clearances_blocks_interceptions),
              mean.comp.pass = mean(completed_passes),
              mean.creativity = mean(creativity),
              mean.dribbles = mean(dribbles),
              mean.err = mean(errors_leading_to_goal),
              mean.fouls = mean(fouls),
              mean.goals.c = mean(goals_conceded),
              mean.goals.s = mean(goals_scored),
              mean.offs = mean(offside),
              mean.cross = mean(open_play_crosses),
              mean.owng = mean(own_goals),
              mean.pen.save = mean(penalties_saved),
              mean.red = mean(red_cards),
              mean.saves = mean(saves),
              mean.tackled = mean(tackled),
              mean.tackles = mean(tackles),
              mean.win.goal = mean(winning_goals),
              mean.points = mean(total_points)) %>% 
    filter(is.na(tree) != TRUE)
  
  
    
    
    
    stepped.lm.tree.7 <- list()
    rmse.values.hc.lm.12 <- NULL
    for(i in 1:11){
      gws.tree.avs.1 <- gws.tree.avs.12.hc %>% 
        filter(tree == i) %>% 
        arrange(-year, -round)
      
      lagged.gws.tree.avs.1 <- as.data.frame(apply(gws.tree.avs.1, 2, lag))
      
      fut.points <- gws.tree.avs.1$mean.points
      
      lagged.gws.tree.avs.1.points <- cbind(lagged.gws.tree.avs.1, fut.points)
      
      
      to.lm.train <- lagged.gws.tree.avs.1.points %>% 
        filter(year == 2016) 
      
      to.lm.test <- lagged.gws.tree.avs.1.points %>% 
        filter(year != 2016)
      
      
      lm.tree <- lm(fut.points ~ . -year -round -tree -mean.points,
                    data = to.lm.train)
      
      stepped.lm.tree.7[[i]] <- step(lm.tree, direction = "both")
      
      predictions.lm.12 <- predict(stepped.lm.tree.7[[i]], to.lm.test[,-27])
      
      true.values <- to.lm.test$fut.points
      
      RMSE.data <- as.data.frame(cbind(true.values, predictions.lm.12))
      
      rmse.values.hc.lm.12[i] <- RMSE.data %>% 
        summarize(rmse = RMSE(RMSE.data$predictions.lm.12, RMSE.data$true.values))
      
      
    }
    
    
    for(i in 12){
      gws.tree.avs.1.12 <- gws.tree.avs.12.hc %>% 
        filter(tree == i) %>% 
        arrange(-year, -round)
      
      lagged.gws.tree.avs.1.12 <- as.data.frame(apply(gws.tree.avs.1.12, 2, lag))
      
      fut.points.12 <- gws.tree.avs.1.12$mean.points
      
      lagged.gws.tree.avs.1.12.points <- cbind(lagged.gws.tree.avs.1.12, fut.points.12)
      
      
      to.lm.train <- lagged.gws.tree.avs.1.12.points %>% 
        filter(year == 2017 & round < 25 ) %>% 
        select(-year, -round, -tree, -mean.points)
      
      
      to.lm.test <- lagged.gws.tree.avs.1.12.points %>% 
        filter((year == 2017 & round >= 25)  |  (year==2018)) %>%
        select(-year, -round, -tree, -mean.points)
      
      
      lm.tree <- lm(fut.points.12 ~ .,
                    data = to.lm.train)
      
      stepped.lm.tree.7[[i]] <- step(lm.tree, direction = "both")
      
      predictions.lm.12 <- predict(stepped.lm.tree.7[[i]], to.lm.test[,-27])
      
      true.values <- to.lm.test$fut.points.12
      
      RMSE.data <- as.data.frame(cbind(true.values, predictions.lm.12))
      
      rmse.values.hc.lm.12[i] <- RMSE.data %>% 
        summarize(rmse = RMSE(RMSE.data$predictions.lm.12, RMSE.data$true.values))
      
      
    }
    
    
    }


  
  
# Now try 12 clusters instead of 7
# Reason being: 1 for each position and 2 for strikers (false 9) DO I NEED TO SUPPORT THIS WITH EVIDENCE AS TO FALSE 9 VS OTHER POSITION?
# RMSE value for linear model for 12 clusters made from kmeans
{
  
  gws.tree.avs.12.k <- gws.tree.12.k %>% 
    group_by(year, round, tree) %>% 
    summarize(mean.assists = mean(assists),
              mean.attempt.pass = mean(attempted_passes),
              mean.big.create = mean(big_chances_created),
              mean.big.miss = mean(big_chances_missed),
              mean.cs = mean(clean_sheets),
              mean.cbs = mean(clearances_blocks_interceptions),
              mean.comp.pass = mean(completed_passes),
              mean.creativity = mean(creativity),
              mean.dribbles = mean(dribbles),
              mean.err = mean(errors_leading_to_goal),
              mean.fouls = mean(fouls),
              mean.goals.c = mean(goals_conceded),
              mean.goals.s = mean(goals_scored),
              mean.offs = mean(offside),
              mean.cross = mean(open_play_crosses),
              mean.owng = mean(own_goals),
              mean.pen.save = mean(penalties_saved),
              mean.red = mean(red_cards),
              mean.saves = mean(saves),
              mean.tackled = mean(tackled),
              mean.tackles = mean(tackles),
              mean.win.goal = mean(winning_goals),
              mean.points = mean(total_points)) %>% 
    filter(is.na(tree) != TRUE)
  

    stepped.lm.tree.7 <- list()
    rmse.values.k.lm.12 <- NULL
    for(i in 1:12){
      gws.tree.avs.1 <- gws.tree.avs.12.k %>% 
        filter(tree == i) %>% 
        arrange(-year, -round)
      
      lagged.gws.tree.avs.1 <- as.data.frame(apply(gws.tree.avs.1, 2, lag))
      
      fut.points <- gws.tree.avs.1$mean.points
      
      lagged.gws.tree.avs.1.points <- cbind(lagged.gws.tree.avs.1, fut.points)
      
      
      to.lm.train <- lagged.gws.tree.avs.1.points %>% 
        filter(year == 2016) 
      
      to.lm.test <- lagged.gws.tree.avs.1.points %>% 
        filter(year != 2016)
      
      
      lm.tree <- lm(fut.points ~ . -year -round -tree -mean.points,
                    data = to.lm.train)
      
      stepped.lm.tree.7[[i]] <- step(lm.tree, direction = "both")
      
      predictions.lm.12 <- predict(stepped.lm.tree.7[[i]], to.lm.test[,-27])
      
      true.values <- to.lm.test$fut.points
      
      RMSE.data <- as.data.frame(cbind(true.values, predictions.lm.12))
      
      rmse.values.k.lm.12[i] <- RMSE.data %>% 
        summarize(rmse = RMSE(RMSE.data$predictions.lm.12, RMSE.data$true.values))
      
      
    }
    
    
    
    
  }
  
  
}



# random forest models 
{

# time to random forest within each cluster woot woot!
# RMSE value for random forest model for 7 clusters made from hierachical
{

  
  
  rf.7 <- list()
  rmse.values.hc.rf.7 <- NULL
  
  for(i in 1:6){
    gws.tree.avs.1.12 <- gws.tree.avs.7.hc %>% 
      filter(tree == i) %>% 
      arrange(-year, -round)
    
    lagged.gws.tree.avs.1.12 <- as.data.frame(apply(gws.tree.avs.1.12, 2, lag))
    
    fut.points.12 <- gws.tree.avs.1.12$mean.points
    
    lagged.gws.tree.avs.1.12.points <- cbind(lagged.gws.tree.avs.1.12, fut.points.12)
    
    
    to.rf.train <- lagged.gws.tree.avs.1.12.points %>% 
      filter(year == 2016) %>% 
      select(-year, -round, -tree, -mean.points)
    
    to.rf.test <- lagged.gws.tree.avs.1.12.points %>% 
      filter(year != 2016) %>%
      select(-year, -round, -tree, -mean.points)
    
    
    rf.7[[i]] <- randomForest(to.rf.train[ ,-23],
                               to.rf.train[ ,23],
                               mtry = 5)
    
    predictions.rf.12 <- predict(rf.7[[i]], to.rf.test[,-23])
    
    true.values <- to.rf.test$fut.points.12
    
    RMSE.data <- as.data.frame(cbind(true.values, predictions.rf.12))
    
    rmse.values.hc.rf.7[i] <- RMSE.data %>% 
      summarize(rmse = RMSE(RMSE.data$predictions.rf.12, RMSE.data$true.values))
    
    
  }
  
  
  for(i in 7){
    gws.tree.avs.1.12 <- gws.tree.avs.7.hc %>% 
      filter(tree == i) %>% 
      arrange(-year, -round)
    
    lagged.gws.tree.avs.1.12 <- as.data.frame(apply(gws.tree.avs.1.12, 2, lag))
    
    fut.points.12 <- gws.tree.avs.1.12$mean.points
    
    lagged.gws.tree.avs.1.12.points <- cbind(lagged.gws.tree.avs.1.12, fut.points.12)
    
    
    to.rf.train <- lagged.gws.tree.avs.1.12.points %>% 
      filter(year == 2017 & round < 25 ) %>% 
      select(-year, -round, -tree, -mean.points)
    
    to.rf.test <- lagged.gws.tree.avs.1.12.points %>% 
      filter((year == 2017 & round >= 25)  |  (year==2018)) %>%
      select(-year, -round, -tree, -mean.points)
    
    
    rf.7[[i]] <- randomForest(to.rf.train[ ,-23],
                               to.rf.train[ ,23],
                               mtry = 5)
    
    predictions.rf.12 <- predict(rf.7[[i]], to.rf.test[,-23])
    
    true.values <- to.rf.test$fut.points.12
    
    RMSE.data <- as.data.frame(cbind(true.values, predictions.rf.12))
    
    rmse.values.hc.rf.7[i] <- RMSE.data %>% 
      summarize(rmse = RMSE(RMSE.data$predictions.rf.12, RMSE.data$true.values))
    
    
  }
  
  
}

  
  
  # time to random forest within each cluster woot woot!
  # RMSE value for random forest model for 7 clusters made from kmeans
  {
    
    
    
    rf.7 <- list()
    rmse.values.k.rf.7 <- NULL
    
    for(i in 1:7){
      gws.tree.avs.1.12 <- gws.tree.avs.7.k %>% 
        filter(tree == i) %>% 
        arrange(-year, -round)
      
      lagged.gws.tree.avs.1.12 <- as.data.frame(apply(gws.tree.avs.1.12, 2, lag))
      
      fut.points.12 <- gws.tree.avs.1.12$mean.points
      
      lagged.gws.tree.avs.1.12.points <- cbind(lagged.gws.tree.avs.1.12, fut.points.12)
      
      
      to.rf.train <- lagged.gws.tree.avs.1.12.points %>% 
        filter(year == 2016) %>% 
        select(-year, -round, -tree, -mean.points)
      
      to.rf.test <- lagged.gws.tree.avs.1.12.points %>% 
        filter(year != 2017) %>%
        select(-year, -round, -tree, -mean.points)
      
      
      rf.7[[i]] <- randomForest(to.rf.train[ ,-23],
                                 to.rf.train[ ,23],
                                 mtry = 5)
      
      predictions.rf.12 <- predict(rf.7[[i]], to.rf.test[,-23])
      
      true.values <- to.rf.test$fut.points.12
      
      RMSE.data <- as.data.frame(cbind(true.values, predictions.rf.12))
      
      rmse.values.k.rf.7[i] <- RMSE.data %>% 
        summarize(rmse = RMSE(RMSE.data$predictions.rf.12, RMSE.data$true.values))
      
      
    }
    
    
  }
  
  
  

# time to random forest within each cluster woot woot!
# RMSE value for random forest model for 12 clusters made from hierachical
  {
    
    
    
    rf.12 <- list()
    rmse.values.hc.rf.12 <- NULL
    
    for(i in 1:11){
      gws.tree.avs.1.12 <- gws.tree.avs.12.hc %>% 
        filter(tree == i) %>% 
        arrange(-year, -round)
      
      lagged.gws.tree.avs.1.12 <- as.data.frame(apply(gws.tree.avs.1.12, 2, lag))
      
      fut.points.12 <- gws.tree.avs.1.12$mean.points
      
      lagged.gws.tree.avs.1.12.points <- cbind(lagged.gws.tree.avs.1.12, fut.points.12)
      
      
      to.rf.train <- lagged.gws.tree.avs.1.12.points %>% 
        filter(year == 2016) %>% 
        select(-year, -round, -tree, -mean.points)
      
      to.rf.test <- lagged.gws.tree.avs.1.12.points %>% 
        filter(year != 2016) %>%
        select(-year, -round, -tree, -mean.points)
      
      
      rf.12[[i]] <- randomForest(to.rf.train[ ,-23],
                                to.rf.train[ ,23],
                                mtry = 5)
      
      predictions.rf.12 <- predict(rf.12[[i]], to.rf.test[,-23])
      
      true.values <- to.rf.test$fut.points.12
      
      RMSE.data <- as.data.frame(cbind(true.values, predictions.rf.12))
      
      rmse.values.hc.rf.12[i] <- RMSE.data %>% 
        summarize(rmse = RMSE(RMSE.data$predictions.rf.12, RMSE.data$true.values))
      
      
    }
    
    
    for(i in 12){
      gws.tree.avs.1.12 <- gws.tree.avs.12.hc %>% 
        filter(tree == i) %>% 
        arrange(-year, -round)
      
      lagged.gws.tree.avs.1.12 <- as.data.frame(apply(gws.tree.avs.1.12, 2, lag))
      
      fut.points.12 <- gws.tree.avs.1.12$mean.points
      
      lagged.gws.tree.avs.1.12.points <- cbind(lagged.gws.tree.avs.1.12, fut.points.12)
      
      
      to.rf.train <- lagged.gws.tree.avs.1.12.points %>% 
        filter(year == 2017 & round < 25 ) %>% 
        select(-year, -round, -tree, -mean.points)
      
      to.rf.test <- lagged.gws.tree.avs.1.12.points %>% 
        filter((year == 2017 & round >= 25)  |  (year==2018)) %>%
        select(-year, -round, -tree, -mean.points)
      
      
      rf.12[[i]] <- randomForest(to.rf.train[ ,-23],
                                to.rf.train[ ,23],
                                mtry = 5)
      
      predictions.rf.12 <- predict(rf.12[[i]], to.rf.test[,-23])
      
      true.values <- to.rf.test$fut.points.12
      
      RMSE.data <- as.data.frame(cbind(true.values, predictions.rf.12))
      
      rmse.values.hc.rf.12[i] <- RMSE.data %>% 
        summarize(rmse = RMSE(RMSE.data$predictions.rf.12, RMSE.data$true.values))
      
      
    }
    
    
  }

  
  
  # time to random forest within each cluster woot woot!
  # RMSE value for random forest model for 12 clusters made from kmeans
  {
    
    
    
    rf.12 <- list()
    rmse.values.k.rf.12 <- NULL
    
    for(i in 1:12){
      gws.tree.avs.1.12 <- gws.tree.avs.12.k %>% 
        filter(tree == i) %>% 
        arrange(-year, -round)
      
      lagged.gws.tree.avs.1.12 <- as.data.frame(apply(gws.tree.avs.1.12, 2, lag))
      
      fut.points.12 <- gws.tree.avs.1.12$mean.points
      
      lagged.gws.tree.avs.1.12.points <- cbind(lagged.gws.tree.avs.1.12, fut.points.12)
      
      
      to.rf.train <- lagged.gws.tree.avs.1.12.points %>% 
        filter(year == 2016) %>% 
        select(-year, -round, -tree, -mean.points)
      
      to.rf.test <- lagged.gws.tree.avs.1.12.points %>% 
        filter(year != 2016) %>%
        select(-year, -round, -tree, -mean.points)
      
      
      rf.12[[i]] <- randomForest(to.rf.train[ ,-23],
                                to.rf.train[ ,23],
                                mtry = 5)
      
      predictions.rf.12 <- predict(rf.12[[i]], to.rf.test[,-23])
      
      true.values <- to.rf.test$fut.points.12
      
      RMSE.data <- as.data.frame(cbind(true.values, predictions.rf.12))
      
      rmse.values.k.rf.12[i] <- RMSE.data %>% 
        summarize(rmse = RMSE(RMSE.data$predictions.rf.12, RMSE.data$true.values))
      
      
    }
    
    
    
    
    
  }
  
  
}




